bayes<-function(inputpath,num)
{
	flag=FALSE;
	path="";
	model=read.table("/etc/profile",sep="\t",stringsAsFactors = FALSE)
                len=length(model[[1]])
                for(i in 1:len)
               {
                    if(grepl("MAHOUTR_HOME",model[[1]][i]))
                 {
                  path=model[[1]][i];
                  flag=TRUE;
                 }
              }
            if(flag==FALSE)
            {
            	cat("please make sure MAHOUTR_HOME is in the /etc/profile\n");
            }
            else
            {
            	    arr=strsplit(path,'=');
                    path=arr[[1]][2];
                    path=paste(path,"/conf/bayes.csv", collapse = NULL,sep="");
                    filedata=c(inputpath,num);
                    write.table(filedata,path);
                    path=arr[[1]][2];
                    path=paste(path,"/lib/shell.jar", collapse = NULL,sep="");
                    .jinit(path);
                    obj=.jnew("shell","bayes");
                    .jcall(obj,"I","rjava");
            } 
}